# EIXO — PWA de Gestão de Vida

Primeira versão funcional do EIXO, construída como PWA instalável.

## O que já existe
- Onboarding e criação de perfil local
- Tela Hoje com prioridades e progresso
- CRUD de tarefas com prioridade, categoria, prazo, horário, subtarefas simples e lembrete
- Metas com progresso e etapas
- Agenda/lista de planejamento
- Área de evolução com estatísticas locais
- Perfil com foto, nome, e-mail e preferências
- Temas Ember, Aurora e Forest + claro/escuro
- Instalação PWA
- Service worker e funcionamento offline para o shell do app
- Notificações locais enquanto a PWA está ativa ou é reaberta
- Persistência local via localStorage

## Rodar localmente
PWA/service worker requer HTTP(S), não `file://`.

```bash
python3 -m http.server 8080
```

Abra `http://localhost:8080`.

## Publicar
Pode ser publicado diretamente como site estático em GitHub Pages, Netlify, Vercel, Cloudflare Pages ou Firebase Hosting.

Depois de publicado em HTTPS, abra pelo Chrome no Android e use “Instalar app”. O próprio EIXO também exibe um botão de instalação quando o navegador disponibiliza o prompt.

## Próxima camada
A estrutura está pronta para receber Supabase/Firebase para autenticação real, sincronização em nuvem, push server-side e backup multi-dispositivo.


## EIXO v0.3
Metas financeiras, Ritmos, Caixa de Entrada, Norte do Dia, Foco EIXO, reflexões e sons de alerta foram adicionados.
