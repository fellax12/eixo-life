(() => {
  'use strict';

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const uid = () => (crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const isoDate = d => new Date(d).toISOString().slice(0,10);
  const todayISO = () => isoDate(new Date());
  const esc = (v='') => String(v).replace(/[&<>'"]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
  const fmtDate = (d, opts={day:'2-digit',month:'short'}) => d ? new Intl.DateTimeFormat('pt-BR',opts).format(new Date(`${d}T12:00:00`)) : '';
  const fmtFull = () => new Intl.DateTimeFormat('pt-BR',{weekday:'long',day:'numeric',month:'long'}).format(new Date());
  const cap = s => s ? s[0].toUpperCase()+s.slice(1) : '';

  const defaults = {
    version: 3,
    onboarded: false,
    loggedIn: false,
    purposes: [],
    profile: { name:'', email:'', phone:'', birth:'', bio:'', avatar:'', memberSince: todayISO() },
    prefs: { theme:'ember', mode:'dark', notifications:true, dailyRitual:true, sound:'pulse', vibrate:true },
    tasks: [],
    goals: [],
    checkins: [],
    habits: [],
    inbox: [],
    focusHistory: [],
    focus: {active:false, startedAt:0, endAt:0, duration:25, label:''},
    lastRoute:'today'
  };

  const seedTasks = () => [
    {id:uid(),title:'Definir as 3 prioridades do dia',notes:'Comece pelo que realmente importa.',date:todayISO(),time:'09:00',priority:'Alta',category:'Pessoal',done:false,reminder:false,createdAt:Date.now()},
    {id:uid(),title:'Separar 20 minutos para você',notes:'Sem notificações. Só espaço para pensar.',date:todayISO(),time:'18:30',priority:'Média',category:'Bem-estar',done:false,reminder:false,createdAt:Date.now()}
  ];
  const seedGoals = () => [
    {id:uid(),title:'Construir uma rotina que funcione para mim',category:'Pessoal',deadline:'',progress:20,steps:[{id:uid(),text:'Escolher minhas prioridades',done:true},{id:uid(),text:'Criar uma rotina mínima',done:false},{id:uid(),text:'Revisar depois de 7 dias',done:false}],createdAt:Date.now()}
  ];

  let state = load();
  let route = state.lastRoute || 'today';
  let taskFilter = 'Todas';
  let planSearch = '';
  let planTab = 'tasks';
  let audioCtx = null;
  let focusTicker = null;
  let deferredInstallPrompt = null;
  let modal = null;

  function load(){
    try {
      const raw = localStorage.getItem('eixo_state_v3') || localStorage.getItem('eixo_state_v2') || localStorage.getItem('eixo_state');
      if (!raw) return structuredClone(defaults);
      const parsed = JSON.parse(raw);
      const out={
        ...structuredClone(defaults), ...parsed,
        profile:{...defaults.profile,...parsed.profile}, prefs:{...defaults.prefs,...parsed.prefs},
        focus:{...defaults.focus,...parsed.focus},
        tasks:Array.isArray(parsed.tasks)?parsed.tasks:[], goals:Array.isArray(parsed.goals)?parsed.goals:[], checkins:Array.isArray(parsed.checkins)?parsed.checkins:[],
        habits:Array.isArray(parsed.habits)?parsed.habits:[], inbox:Array.isArray(parsed.inbox)?parsed.inbox:[], focusHistory:Array.isArray(parsed.focusHistory)?parsed.focusHistory:[]
      };
      out.goals=out.goals.map(g=>({type:'general',currency:'BRL',targetAmount:0,currentAmount:0,financialHistory:[],...g}));
      return out;
    } catch { return structuredClone(defaults); }
  }
  function save(){ localStorage.setItem('eixo_state_v3',JSON.stringify(state)); localStorage.setItem('eixo_state',JSON.stringify(state)); }
  function patch(mutator){ mutator(state); save(); render(); }

  function applyTheme(){
    document.documentElement.dataset.theme = state.prefs.theme;
    document.documentElement.dataset.mode = state.prefs.mode;
    const themeColor = state.prefs.mode === 'light' ? '#f4f5f7' : '#0b0d10';
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content',themeColor);
  }

  function toast(msg){
    const root = $('#toast-root');
    root.innerHTML = `<div class="toast">${esc(msg)}</div>`;
    setTimeout(()=>{ if(root) root.innerHTML=''; },2200);
  }

  function firstName(){ return (state.profile.name || 'você').trim().split(/\s+/)[0]; }
  function initials(){
    const parts=(state.profile.name||'Eixo').trim().split(/\s+/).slice(0,2);
    return parts.map(p=>p[0]?.toUpperCase()).join('') || 'E';
  }
  function avatarHtml(cls='avatar'){
    return `<div class="${cls}">${state.profile.avatar?`<img src="${state.profile.avatar}" alt="Foto de perfil">`:esc(initials())}</div>`;
  }
  function tasksToday(){ return state.tasks.filter(t=>t.date===todayISO()); }
  function completionPct(){ const a=tasksToday(); return a.length?Math.round(a.filter(t=>t.done).length/a.length*100):0; }
  function streak(){
    const doneDates = new Set(state.tasks.filter(t=>t.done&&t.date).map(t=>t.date));
    let n=0,d=new Date();
    for(let i=0;i<365;i++){const k=isoDate(d);if(doneDates.has(k))n++;else if(i>0)break;d.setDate(d.getDate()-1)}
    return n;
  }

  function money(v,c='BRL'){try{return new Intl.NumberFormat('pt-BR',{style:'currency',currency:c,maximumFractionDigits:2}).format(Number(v)||0)}catch{return `${c} ${(Number(v)||0).toFixed(2)}`}}
  function goalProgress(g){if(g.type==='financial'){const t=Number(g.targetAmount)||0;return t?Math.max(0,Math.min(100,Math.round((Number(g.currentAmount)||0)/t*100))):0}return Math.max(0,Math.min(100,Number(g.progress)||0))}
  function weekStart(){const d=new Date(),x=new Date(d),n=(x.getDay()+6)%7;x.setDate(x.getDate()-n);x.setHours(0,0,0,0);return x}
  function weekDates(){const s=weekStart();return Array.from({length:7},(_,i)=>{const d=new Date(s);d.setDate(d.getDate()+i);return isoDate(d)})}
  function habitWeekCount(h){const set=new Set(h.completions||[]);return weekDates().filter(d=>set.has(d)).length}
  function habitStreak(h){const set=new Set(h.completions||[]);let n=0,d=new Date();for(let i=0;i<365;i++){const k=isoDate(d);if(set.has(k)){n++;d.setDate(d.getDate()-1)}else if(i===0)d.setDate(d.getDate()-1);else break}return n}
  function fmtClock(ms){const s=Math.max(0,Math.ceil(ms/1000)),m=Math.floor(s/60);return `${String(m).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`}
  function focusRemaining(){return state.focus?.active?Math.max(0,Number(state.focus.endAt)-Date.now()):0}
  function soundLabel(n){return n==='horizon'?'Horizonte':n==='calm'?'Calma':n==='minimal'?'Minimal':'Pulso'}
  function ensureAudio(){if(!audioCtx)audioCtx=new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();return audioCtx}
  function tone(freq,start,dur,vol=.07,type='sine'){const c=ensureAudio(),o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(freq,c.currentTime+start);g.gain.setValueAtTime(.001,c.currentTime+start);g.gain.exponentialRampToValueAtTime(vol,c.currentTime+start+.02);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+start+dur);o.connect(g);g.connect(c.destination);o.start(c.currentTime+start);o.stop(c.currentTime+start+dur+.03)}
  function playTone(name,preview=false){try{if(name==='horizon'){tone(392,0,.2);tone(523,.17,.25);tone(659,.38,.34,.055)}else if(name==='calm'){tone(440,0,.36,.045);tone(554,.28,.44,.04);tone(659,.57,.5,.035)}else if(name==='minimal'){tone(740,0,.11,.06,'triangle');tone(880,.16,.12,.05,'triangle')}else{tone(523,0,.13);tone(659,.14,.13,.06);tone(784,.28,.2,.05)}if(preview)toast(`Prévia: ${soundLabel(name)}`)}catch{if(preview)toast('O navegador bloqueou a prévia de áudio.')}}
  function focusChip(){return state.focus?.active?`<button class="focus-chip" data-focus-open>◉ Foco · <span id="focus-chip-time">${fmtClock(focusRemaining())}</span></button>`:''}

  function nav(){
    const items=[['today','⌂','Hoje'],['plan','▤','Planejar'],['goals','◎','Metas'],['evolution','↗','Evolução'],['profile','◉','Perfil']];
    return `<nav class="bottom-nav">${items.map(([r,i,l])=>`<button class="nav-item ${route===r?'active':''}" data-route="${r}"><span class="ico">${i}</span><span>${l}</span></button>`).join('')}</nav>`;
  }
  function topbar(){
    const hour=new Date().getHours(); const greet=hour<12?'Bom dia':hour<18?'Boa tarde':'Boa noite';
    return `<header class="topbar"><div><div class="greeting">${greet}, ${esc(firstName())}.</div><div class="date-line">${cap(fmtFull())}</div></div><button class="more-btn" data-route="profile" aria-label="Abrir perfil">${avatarHtml('avatar')}</button></header>`;
  }

  function onboarding(){
    const step = modal?.onboardStep || 1;
    if(step===1) return `<main class="onboarding">
      <div><div class="brand-mark">+</div><div class="brand" style="margin-top:18px">EIXO</div>
      <h1>Sua vida.<br>Sua direção.</h1><p class="lead">Um lugar para organizar o que importa, transformar metas em próximos passos e voltar a sentir que o seu dia está nas suas mãos.</p></div>
      <div class="onboarding-actions"><button class="btn primary full" data-onboard-next>Começar meu EIXO</button><div class="small muted" style="text-align:center">Seus dados ficam neste aparelho nesta primeira versão.</div></div></main>`;

    if(step===2) return `<main class="onboarding">
      <div><div class="eyebrow">Personalização</div><h1 style="font-size:36px">O que você quer colocar no eixo primeiro?</h1><p class="lead">Escolha quantos quiser. Isso vai orientar a sua experiência inicial.</p>
      <div class="purpose-grid">${[
        ['🧭','Organizar minha rotina','Ter clareza sobre o que fazer e quando.'],['✓','Concluir o que venho adiando','Tirar pendências da cabeça e levar para a ação.'],['◎','Construir novas metas','Transformar desejos em etapas concretas.'],['◷','Ter mais controle dos meus dias','Planejar sem transformar a vida numa planilha.'],['✦','Um pouco de tudo','Quero uma central completa para a minha vida.']
      ].map((x,i)=>`<div class="purpose ${state.purposes.includes(i)?'active':''}" data-purpose="${i}"><i>${x[0]}</i><div><b>${x[1]}</b><span>${x[2]}</span></div></div>`).join('')}</div></div>
      <div class="onboarding-actions"><button class="btn primary full" data-onboard-next>Continuar</button><button class="btn ghost full" data-onboard-back>Voltar</button></div></main>`;

    return `<main class="onboarding"><div><div class="eyebrow">Seu espaço</div><h1 style="font-size:36px">Como podemos te chamar?</h1><p class="lead">Esse é o começo do seu espaço pessoal no EIXO.</p>
      <div class="form" style="margin-top:28px"><div class="field"><label>SEU NOME</label><input id="on-name" autocomplete="name" placeholder="Ex.: Gabriel" value="${esc(state.profile.name)}"></div><div class="field"><label>E-MAIL</label><input id="on-email" type="email" autocomplete="email" placeholder="voce@email.com" value="${esc(state.profile.email)}"></div></div></div>
      <div class="onboarding-actions"><button class="btn primary full" data-onboard-finish>Entrar no meu EIXO</button><button class="btn ghost full" data-onboard-back>Voltar</button></div></main>`;
  }

  function loginView(){ return `<main class="onboarding"><div><div class="brand-mark">+</div><div class="brand" style="margin-top:18px">EIXO</div><h1>Bem-vindo<br>de volta.</h1><p class="lead">Seu espaço continua do jeito que você deixou.</p></div><div class="onboarding-actions"><button class="btn primary full" data-login>Entrar como ${esc(firstName())}</button><button class="btn secondary full" data-reset-login>Usar outro perfil neste aparelho</button></div></main>`; }

  function todayPage(){
    const list=tasksToday().sort((a,b)=>Number(a.done)-Number(b.done)||(a.time||'99:99').localeCompare(b.time||'99:99'));
    const pct=completionPct();
    const north=list.filter(t=>!t.done&&t.northDate===todayISO()).slice(0,3);
    return `<div class="page">${topbar()}${installBanner()}
      <section class="card hero"><div class="hero-row"><div class="progress-ring" style="--p:${pct}"><div style="text-align:center"><strong>${pct}%</strong><br><span>do dia</span></div></div><div class="hero-copy"><div class="eyebrow">Seu dia</div><h2>${pct===100&&list.length?'Dia concluído.':'Um passo de cada vez.'}</h2><p>${list.length?`${list.filter(t=>t.done).length} de ${list.length} tarefas concluídas hoje.`:'Seu dia ainda está em branco. Escolha o que realmente merece espaço.'}</p><div class="streak">✦ ${streak()} ${streak()===1?'dia':'dias'} em movimento</div></div></div></section>
      <div class="quick-grid">
        <div class="quick-card" data-new="task"><div class="quick-icon">＋</div><div><b>Nova tarefa</b><span>Um próximo passo</span></div></div>
        <div class="quick-card" data-capture><div class="quick-icon">⌁</div><div><b>Capturar</b><span>Tire da cabeça</span></div></div>
        <div class="quick-card" data-focus-open><div class="quick-icon">◉</div><div><b>Foco EIXO</b><span>Proteja sua atenção</span></div></div>
        <div class="quick-card" data-checkin><div class="quick-icon">☼</div><div><b>Check-in</b><span>Perceba seu dia</span></div></div>
      </div>
      <section class="section card north-card"><div class="north-head"><div><div class="eyebrow">Norte do Dia</div><h3>O que realmente importa hoje?</h3></div><button class="btn secondary" data-north>Definir</button></div>${north.length?north.map(t=>`<div class="north-item"><i></i><span>${esc(t.title)}</span></div>`).join(''):`<p class="muted small" style="margin-top:10px">Escolha até 3 tarefas para proteger sua atenção.</p>`}</section>
      <section class="section"><div style="display:flex;justify-content:space-between;align-items:center"><h2 class="section-title">Ritmos de hoje</h2><button class="btn ghost" data-plan-tab="habits">Ver todos</button></div><div class="list">${state.habits.length?state.habits.slice(0,3).map(habitHtml).join(''):`<div class="empty"><b>Crie um ritmo.</b>Hábitos pequenos sustentam direções grandes.</div>`}</div></section>
      <section class="section"><div style="display:flex;justify-content:space-between;align-items:center"><h2 class="section-title">Hoje</h2><button class="btn ghost" data-route="plan">Ver tudo</button></div><div class="list">${list.length?list.map(taskHtml).join(''):`<div class="empty"><b>Seu dia começa aqui.</b>Adicione uma tarefa e escolha o próximo passo.</div>`}</div></section>
      ${activeGoalsMini()}
    </div><button class="fab" aria-label="Adicionar" data-quick-menu>＋</button>${focusChip()}${nav()}`;
  }
  function taskHtml(t){
    const overdue=t.date && t.date<todayISO() && !t.done;
    const rep=t.repeat&&t.repeat!=='none'?`<span class="pill">↻ ${t.repeat==='daily'?'diária':t.repeat==='weekly'?'semanal':'mensal'}</span>`:'';
    return `<article class="task ${t.done?'done':''}" data-task="${t.id}"><button class="check" data-toggle-task="${t.id}" aria-label="Concluir tarefa">${t.done?'✓':''}</button><div class="task-body"><div class="task-title">${esc(t.title)}</div><div class="task-meta">${t.time?`<span class="pill ${overdue?'danger':''}">◷ ${esc(t.time)}</span>`:''}${t.date&&t.date!==todayISO()?`<span class="pill">${fmtDate(t.date)}</span>`:''}<span class="pill">${esc(t.category||'Geral')}</span>${t.priority==='Alta'?'<span class="pill accent">Alta prioridade</span>':''}${rep}${t.reminder?'<span class="pill">◉ Lembrete</span>':''}</div></div><button class="more-btn" data-edit-task="${t.id}" aria-label="Editar">•••</button></article>`;
  }
  function habitHtml(h){
    const done=(h.completions||[]).includes(todayISO()),count=habitWeekCount(h),target=Math.max(1,Number(h.targetPerWeek)||7);
    return `<article class="habit-row ${done?'done':''}"><button class="check" data-toggle-habit="${h.id}">${done?'✓':''}</button><div class="task-body" data-edit-habit="${h.id}"><div class="task-title">${esc(h.title)}</div><div class="task-meta"><span class="pill">${count}/${target} nesta semana</span><span class="pill">${habitStreak(h)} dia(s) de sequência</span>${h.time?`<span class="pill">◷ ${h.time}</span>`:''}</div><div class="rhythm-dots">${Array.from({length:target},(_,i)=>`<i class="${i<count?'on':''}"></i>`).join('')}</div></div><button class="more-btn" data-edit-habit="${h.id}">•••</button></article>`;
  }

  function activeGoalsMini(){
    const goals=state.goals.slice(0,2); if(!goals.length)return '';
    return `<section class="section"><div style="display:flex;justify-content:space-between;align-items:center"><h2 class="section-title">Metas em movimento</h2><button class="btn ghost" data-route="goals">Ver todas</button></div><div class="list">${goals.map(goalHtml).join('')}</div></section>`;
  }

  function planPage(){
    if(planTab==='habits') return `<div class="page"><header class="topbar"><div><div class="eyebrow">Consistência</div><div class="greeting">Ritmos</div></div><button class="icon-btn" data-new-habit>＋</button></header>${planTabs()}<p class="muted small" style="line-height:1.5">Ritmos são hábitos que sustentam sua direção. Sem culpa por quebrar sequência: o objetivo é voltar.</p><section class="section"><div class="list">${state.habits.length?state.habits.map(habitHtml).join(''):`<div class="empty"><b>Nenhum ritmo ainda.</b>Crie algo pequeno que você queira repetir.</div>`}</div></section></div><button class="fab" data-new-habit>＋</button>${nav()}`;
    if(planTab==='inbox') return `<div class="page"><header class="topbar"><div><div class="eyebrow">Captura rápida</div><div class="greeting">Caixa de Entrada</div></div></header>${planTabs()}<p class="muted small" style="line-height:1.5">Capture agora. Organize depois. Sua cabeça não precisa funcionar como um lembrete.</p><form class="capture-bar" id="capture-form"><input name="text" required maxlength="180" placeholder="O que está na sua cabeça?"><button class="btn primary">Guardar</button></form><section class="section"><div class="list">${state.inbox.length?[...state.inbox].reverse().map(i=>`<div class="inbox-row"><div class="task-body"><div class="task-title">${esc(i.text)}</div><div class="small muted">${new Date(i.createdAt).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}</div></div><button class="btn secondary" data-inbox-task="${i.id}">→ tarefa</button><button class="more-btn" data-delete-inbox="${i.id}">×</button></div>`).join(''):`<div class="empty"><b>Caixa vazia.</b>Bom sinal.</div>`}</div></section></div>${nav()}`;
    let list=[...state.tasks];
    if(taskFilter==='Hoje') list=list.filter(t=>t.date===todayISO());
    if(taskFilter==='Pendentes') list=list.filter(t=>!t.done);
    if(taskFilter==='Concluídas') list=list.filter(t=>t.done);
    if(planSearch) list=list.filter(t=>(t.title+' '+(t.notes||'')+' '+(t.category||'')).toLowerCase().includes(planSearch.toLowerCase()));
    list.sort((a,b)=>(a.date||'9999').localeCompare(b.date||'9999')||(a.time||'99').localeCompare(b.time||'99'));
    return `<div class="page"><header class="topbar"><div><div class="eyebrow">Organização</div><div class="greeting">Planejar</div></div><button class="icon-btn" data-new="task">＋</button></header>${planTabs()}
      <div class="search"><span>⌕</span><input id="plan-search" placeholder="Buscar tarefas, categorias..." value="${esc(planSearch)}"></div>
      <div class="filters">${['Todas','Hoje','Pendentes','Concluídas'].map(f=>`<button class="filter ${taskFilter===f?'active':''}" data-filter="${f}">${f}</button>`).join('')}</div>
      <section class="section"><div class="list">${list.length?list.map(taskHtml).join(''):`<div class="empty"><b>Nada por aqui.</b>Seu planejamento está livre neste filtro.</div>`}</div></section>
      <section class="section"><h2 class="section-title">Visão dos próximos 7 dias</h2><div class="mini-calendar">${weekCalendar()}</div></section>
    </div><button class="fab" data-new="task">＋</button>${nav()}`;
  }
  function planTabs(){return `<div class="segment"><button class="${planTab==='tasks'?'active':''}" data-plan-tab="tasks">Tarefas</button><button class="${planTab==='habits'?'active':''}" data-plan-tab="habits">Ritmos</button><button class="${planTab==='inbox'?'active':''}" data-plan-tab="inbox">Caixa</button></div>`}

  function weekCalendar(){
    const arr=[]; const now=new Date();
    for(let i=0;i<7;i++){const d=new Date(now);d.setDate(now.getDate()+i);const k=isoDate(d);const has=state.tasks.some(t=>t.date===k);arr.push(`<div class="day ${has?'has':''} ${i===0?'today':''}"><div><b>${d.getDate()}</b><br><span>${new Intl.DateTimeFormat('pt-BR',{weekday:'narrow'}).format(d)}</span></div></div>`)}
    return arr.join('');
  }

  function goalsPage(){
    const done=state.goals.filter(g=>goalProgress(g)>=100).length;
    return `<div class="page"><header class="topbar"><div><div class="eyebrow">Direção</div><div class="greeting">Metas</div></div><button class="icon-btn" data-new="goal">＋</button></header>
      <section class="card hero"><div class="eyebrow">Visão geral</div><h2 style="font:800 24px Manrope;margin-top:7px">${done} conquistadas. ${state.goals.length-done} em movimento.</h2><p class="muted" style="margin-top:9px;font-size:13px">Metas podem ser de evolução ou financeiras. O EIXO mostra o caminho sem esconder o progresso real.</p></section>
      <section class="section"><div class="list">${state.goals.length?state.goals.map(goalHtml).join(''):`<div class="empty"><b>Qual direção você quer dar agora?</b>Crie uma meta e transforme-a em etapas concretas.</div>`}</div></section>
    </div><button class="fab" data-new="goal">＋</button>${nav()}`;
  }
  function goalHtml(g){
    const p=goalProgress(g);
    if(g.type==='financial'){
      const cur=Number(g.currentAmount)||0,target=Number(g.targetAmount)||0,left=Math.max(0,target-cur);
      return `<article class="card goal-card"><div class="goal-head"><div><div class="eyebrow">Meta financeira</div><h3>${esc(g.title)}</h3><p>${g.deadline?`Prazo · ${fmtDate(g.deadline,{day:'2-digit',month:'long',year:'numeric'})}`:'Sem prazo rígido'}</p></div><button class="more-btn" data-edit-goal="${g.id}">•••</button></div><div class="money-current">${money(cur,g.currency)}</div><div class="small muted">de ${money(target,g.currency)} · faltam ${money(left,g.currency)}</div><div class="bar"><i style="width:${p}%"></i></div><div class="goal-foot"><button class="btn primary compact" data-contribute="${g.id}">＋ Registrar valor</button><strong>${p}%</strong></div></article>`;
    }
    return `<article class="card goal-card"><div class="goal-head"><div><div class="eyebrow">${esc(g.category||'Meta')}</div><h3>${esc(g.title)}</h3><p>${g.deadline?`Prazo · ${fmtDate(g.deadline,{day:'2-digit',month:'long',year:'numeric'})}`:'Sem prazo rígido'}</p></div><button class="more-btn" data-edit-goal="${g.id}">•••</button></div><div class="bar"><i style="width:${p}%"></i></div><div class="goal-foot"><span>${(g.steps||[]).filter(s=>s.done).length}/${(g.steps||[]).length} etapas</span><strong>${p}%</strong></div></article>`;
  }
  function evolutionPage(){
    const done=state.tasks.filter(t=>t.done).length,total=state.tasks.length,thisWeek=last7Counts();
    const active=state.goals.filter(g=>goalProgress(g)<100).length;
    const now=Date.now(),focusMin=Math.round(state.focusHistory.filter(x=>now-x.completedAt<7*86400000).reduce((a,x)=>a+(Number(x.duration)||0),0));
    const rhythmDone=state.habits.reduce((a,h)=>a+habitWeekCount(h),0),rhythmTarget=state.habits.reduce((a,h)=>a+Math.max(1,Number(h.targetPerWeek)||7),0);
    const lastCheck=state.checkins[state.checkins.length-1];
    return `<div class="page"><header class="topbar"><div><div class="eyebrow">Consistência</div><div class="greeting">Evolução</div></div><div class="icon-btn">↗</div></header>
      <div class="stats-grid"><div class="card stat"><strong>${done}</strong><span>Tarefas concluídas</span></div><div class="card stat"><strong>${focusMin}m</strong><span>Foco nesta semana</span></div><div class="card stat"><strong>${active}</strong><span>Metas ativas</span></div><div class="card stat"><strong>${rhythmDone}</strong><span>Ritmos cumpridos</span></div></div>
      <section class="section card chart"><div class="eyebrow">Últimos 7 dias</div><h2 class="section-title" style="margin-top:6px">Passos concluídos</h2><div class="bars">${thisWeek.map(x=>`<div class="bar-col"><i style="height:${Math.max(6,x.count*25)}px"></i><span>${x.label}</span></div>`).join('')}</div></section>
      <section class="section card" style="padding:18px"><div class="eyebrow">Pulso da semana</div><div class="metric-row"><div><b>${done}</b><span>passos</span></div><div><b>${rhythmDone}/${rhythmTarget}</b><span>ritmos</span></div><div><b>${focusMin}m</b><span>foco</span></div></div></section>
      ${lastCheck?`<section class="section card" style="padding:18px"><div class="eyebrow">Última reflexão</div><h2 class="section-title" style="margin-top:6px">${esc(lastCheck.mood||'Check-in')}</h2>${lastCheck.win?`<p><b>Vitória:</b> ${esc(lastCheck.win)}</p>`:''}${lastCheck.note?`<p class="muted small">${esc(lastCheck.note)}</p>`:''}</section>`:''}
      <section class="section card" style="padding:18px"><div class="eyebrow">Leitura do momento</div><h2 class="section-title" style="margin-top:6px">${insightTitle()}</h2><p class="muted" style="font-size:13px;line-height:1.6">${insightText()}</p></section>
    </div>${nav()}`;
  }
  function last7Counts(){
    const out=[]; for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=isoDate(d);out.push({label:new Intl.DateTimeFormat('pt-BR',{weekday:'narrow'}).format(d),count:state.tasks.filter(t=>t.done&&t.date===k).length})} return out;
  }
  function insightTitle(){ const p=completionPct(); if(p>=80)return 'Você está fechando bem o que começa.'; if(state.tasks.length===0)return 'Seu histórico ainda está começando.'; return 'Clareza antes de quantidade.'; }
  function insightText(){ const pending=state.tasks.filter(t=>!t.done).length; if(!state.tasks.length)return 'Crie algumas tarefas e metas. O EIXO vai transformar seu uso em uma visão simples da sua consistência.'; return `Você tem ${pending} ${pending===1?'pendência':'pendências'} no sistema. Em vez de tentar acelerar tudo, escolha uma prioridade real para hoje e proteja espaço para concluí-la.`; }

  function profilePage(){
    return `<div class="page"><header class="topbar"><div><div class="eyebrow">Conta & experiência</div><div class="greeting">Perfil</div></div><button class="icon-btn" data-edit-profile>✎</button></header>
      <section class="card profile-hero">${avatarHtml('profile-avatar')}<div class="profile-name">${esc(state.profile.name||'Seu nome')}</div><div class="muted small" style="margin-top:5px">${esc(state.profile.email||'Complete seu perfil')}</div><div class="streak">✦ Membro desde ${fmtDate(state.profile.memberSince,{month:'long',year:'numeric'})}</div></section>
      <section class="section"><h2 class="section-title">Aparência</h2><div class="card settings-group"><div class="setting"><div class="setting-ico">◐</div><div class="setting-copy"><b>Modo</b><span>Claro ou escuro</span></div><button class="btn secondary" data-toggle-mode>${state.prefs.mode==='dark'?'Escuro':'Claro'}</button></div><div class="setting"><div class="setting-ico">✦</div><div class="setting-copy"><b>Cor do EIXO</b><span>Escolha a energia visual</span></div><div class="theme-swatches">${['ember','aurora','forest'].map(t=>`<button aria-label="Tema ${t}" class="swatch ${t} ${state.prefs.theme===t?'active':''}" data-theme-choice="${t}"></button>`).join('')}</div></div></div></section>
      <section class="section"><h2 class="section-title">Alertas</h2><div class="card settings-group"><div class="setting"><div class="setting-ico">◉</div><div class="setting-copy"><b>Notificações</b><span>Lembretes e avisos importantes</span></div><div class="switch ${state.prefs.notifications?'on':''}" data-pref="notifications"><i></i></div></div><div class="setting"><div class="setting-ico">♫</div><div class="setting-copy"><b>Som EIXO</b><span>Som do app quando ele estiver ativo</span></div><div class="sound-controls"><select id="sound-choice"><option value="pulse">Pulso</option><option value="horizon">Horizonte</option><option value="calm">Calma</option><option value="minimal">Minimal</option></select><button class="btn secondary" data-preview-sound>▶</button></div></div><div class="setting"><div class="setting-ico">〰</div><div class="setting-copy"><b>Vibração</b><span>Quando suportado pelo aparelho</span></div><div class="switch ${state.prefs.vibrate?'on':''}" data-pref="vibrate"><i></i></div></div></div><div class="small muted" style="padding:10px 3px;line-height:1.5">No Android, notificações web em segundo plano podem usar o som padrão do sistema. O som escolhido acima toca nos alertas do EIXO enquanto o app está ativo.</div></section>
      <section class="section"><h2 class="section-title">Seus dados</h2><div class="card settings-group"><div class="setting" data-edit-profile><div class="setting-ico">◉</div><div class="setting-copy"><b>Dados pessoais</b><span>Nome, foto, telefone, nascimento e bio</span></div><div class="setting-action">›</div></div><div class="setting" data-export><div class="setting-ico">⇩</div><div class="setting-copy"><b>Exportar meus dados</b><span>Baixe uma cópia em JSON</span></div><div class="setting-action">›</div></div></div></section>
      <section class="section"><div class="card settings-group danger-zone"><div class="setting" data-logout><div class="setting-ico">↪</div><div class="setting-copy"><b>Sair</b><span>Desconectar deste perfil</span></div><div class="setting-action">›</div></div></div></section>
      <div style="text-align:center;margin:22px 0" class="small muted">EIXO v0.3 · Seu próximo passo importa.</div>
    </div>${nav()}`;
  }
  function installBanner(){
    if(!deferredInstallPrompt) return '';
    return `<div class="install-banner"><div class="quick-icon">＋</div><div class="copy"><b>Leve o EIXO com você</b><span>Instale no celular e abra como um aplicativo.</span></div><button class="btn primary" data-install>Instalar</button></div>`;
  }

  function appView(){
    let body='';
    if(route==='today') body=todayPage();
    if(route==='plan') body=planPage();
    if(route==='goals') body=goalsPage();
    if(route==='evolution') body=evolutionPage();
    if(route==='profile') body=profilePage();
    return `<div class="app-shell">${body}${modalHtml()}</div>`;
  }

  function modalHtml(){
    if(!modal || modal.onboardStep) return '';
    if(modal.type==='quick') return sheet('Adicionar ao EIXO',`<div class="quick-grid" style="grid-template-columns:1fr 1fr;margin-top:0"><div class="quick-card" data-new="task"><div class="quick-icon">＋</div><div><b>Tarefa</b><span>Algo a fazer</span></div></div><div class="quick-card" data-new="goal"><div class="quick-icon">◎</div><div><b>Meta</b><span>Uma direção</span></div></div><div class="quick-card" data-capture><div class="quick-icon">⌁</div><div><b>Capturar</b><span>Tire da cabeça</span></div></div><div class="quick-card" data-focus-open><div class="quick-icon">◉</div><div><b>Foco</b><span>Proteja atenção</span></div></div></div>`);
    if(modal.type==='task') return taskModal(modal.id);
    if(modal.type==='goal') return goalModal(modal.id);
    if(modal.type==='contribute') return contributionModal(modal.id);
    if(modal.type==='habit') return habitModal(modal.id);
    if(modal.type==='capture') return captureModal();
    if(modal.type==='focus') return focusModal();
    if(modal.type==='north') return northModal();
    if(modal.type==='profile') return profileModal();
    if(modal.type==='checkin') return checkinModal();
    return '';
  }
  function sheet(title,content){ return `<div class="modal-backdrop" data-close-modal><div class="sheet" onclick="event.stopPropagation()"><div class="sheet-handle"></div><div class="sheet-head"><h2>${title}</h2><button class="icon-btn" data-close-modal>×</button></div>${content}</div></div>`; }
  function taskModal(id){
    const t=state.tasks.find(x=>x.id===id)||{title:modal?.prefill||'',notes:'',date:todayISO(),time:'',priority:'Média',category:'Pessoal',reminder:false,repeat:'none'};
    return sheet(id?'Editar tarefa':'Nova tarefa',`<form class="form" id="task-form" data-id="${id||''}"><div class="field"><label>TÍTULO</label><input name="title" required autofocus placeholder="O que precisa acontecer?" value="${esc(t.title)}"></div><div class="field"><label>NOTAS</label><textarea name="notes" placeholder="Contexto, detalhes, links...">${esc(t.notes||'')}</textarea></div><div class="row"><div class="field"><label>DATA</label><input name="date" type="date" value="${esc(t.date||todayISO())}"></div><div class="field"><label>HORÁRIO</label><input name="time" type="time" value="${esc(t.time||'')}"></div></div><div class="row"><div class="field"><label>PRIORIDADE</label><select name="priority">${['Baixa','Média','Alta'].map(x=>`<option ${t.priority===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label>CATEGORIA</label><select name="category">${['Pessoal','Trabalho','Estudos','Financeiro','Bem-estar','Casa','Geral'].map(x=>`<option ${t.category===x?'selected':''}>${x}</option>`).join('')}</select></div></div><div class="field"><label>REPETIÇÃO</label><select name="repeat"><option value="none" ${!t.repeat||t.repeat==='none'?'selected':''}>Não repetir</option><option value="daily" ${t.repeat==='daily'?'selected':''}>Diariamente</option><option value="weekly" ${t.repeat==='weekly'?'selected':''}>Semanalmente</option><option value="monthly" ${t.repeat==='monthly'?'selected':''}>Mensalmente</option></select></div><label class="setting" style="padding:4px 2px;border:0"><div class="setting-copy"><b>Lembrete</b><span>Notificar na data e horário quando permitido</span></div><input name="reminder" type="checkbox" ${t.reminder?'checked':''} style="width:20px;height:20px;accent-color:var(--accent)"></label><button class="btn primary full" type="submit">${id?'Salvar alterações':'Criar tarefa'}</button>${id?`<button class="btn danger full" type="button" data-delete-task="${id}">Excluir tarefa</button>`:''}</form>`);
  }
  function goalModal(id){
    const g=state.goals.find(x=>x.id===id)||{type:'general',title:'',category:'Pessoal',deadline:'',progress:0,steps:[],currency:'BRL',targetAmount:0,currentAmount:0};
    return sheet(id?'Editar meta':'Nova meta',`<form class="form" id="goal-form" data-id="${id||''}"><div class="field"><label>TIPO DE META</label><select name="type" id="goal-type"><option value="general" ${g.type!=='financial'?'selected':''}>Evolução pessoal</option><option value="financial" ${g.type==='financial'?'selected':''}>Financeira</option></select></div><div class="field"><label>QUAL É A META?</label><input name="title" required placeholder="Ex.: Montar minha reserva" value="${esc(g.title)}"></div><div class="row"><div class="field"><label>CATEGORIA</label><select name="category">${['Pessoal','Profissional','Financeiro','Estudos','Bem-estar','Projeto'].map(x=>`<option ${g.category===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label>PRAZO</label><input name="deadline" type="date" value="${esc(g.deadline||'')}"></div></div><div id="general-goal-fields" style="display:${g.type==='financial'?'none':'block'}"><div class="field"><label>PROGRESSO · <span id="progress-label">${Number(g.progress)||0}%</span></label><input name="progress" id="goal-progress" type="range" min="0" max="100" step="5" value="${Number(g.progress)||0}" style="accent-color:var(--accent)"></div><div class="field"><label>ETAPAS · UMA POR LINHA</label><textarea name="steps" placeholder="Pesquisar opções
Definir próximo passo
Executar">${esc((g.steps||[]).map(s=>`${s.done?'✓ ':''}${s.text}`).join('\n'))}</textarea></div></div><div id="financial-goal-fields" style="display:${g.type==='financial'?'block':'none'}"><div class="field"><label>MOEDA</label><select name="currency"><option value="BRL" ${g.currency==='BRL'?'selected':''}>Real (R$)</option><option value="USD" ${g.currency==='USD'?'selected':''}>Dólar (US$)</option><option value="EUR" ${g.currency==='EUR'?'selected':''}>Euro (€)</option></select></div><div class="row"><div class="field"><label>VALOR-ALVO</label><input name="targetAmount" type="number" inputmode="decimal" min="0" step="0.01" placeholder="5000" value="${Number(g.targetAmount)||''}"></div><div class="field"><label>QUANTO JÁ TEM</label><input name="currentAmount" type="number" inputmode="decimal" min="0" step="0.01" placeholder="750" value="${Number(g.currentAmount)||''}"></div></div><div class="small muted">O progresso é calculado automaticamente conforme você registra valores.</div></div><button class="btn primary full" type="submit">${id?'Salvar meta':'Criar meta'}</button>${id?`<button class="btn danger full" type="button" data-delete-goal="${id}">Excluir meta</button>`:''}</form>`);
  }
  function contributionModal(id){const g=state.goals.find(x=>x.id===id);if(!g)return '';return sheet('Registrar avanço',`<div class="money-box"><div class="eyebrow">${esc(g.title)}</div><strong>${money(g.currentAmount,g.currency)}</strong><span>de ${money(g.targetAmount,g.currency)}</span></div><form class="form" id="contribution-form" data-id="${g.id}"><div class="field"><label>VALOR A ADICIONAR</label><input name="amount" type="number" inputmode="decimal" min="0.01" step="0.01" required placeholder="100"></div><div class="field"><label>OBSERVAÇÃO</label><input name="note" maxlength="80" placeholder="Ex.: aporte de setembro"></div><button class="btn primary full">Adicionar à meta</button></form>`)}
  function habitModal(id){const h=state.habits.find(x=>x.id===id)||{title:'',category:'Bem-estar',targetPerWeek:5,time:''};return sheet(id?'Editar ritmo':'Novo ritmo',`<form class="form" id="habit-form" data-id="${id||''}"><div class="field"><label>RITMO / HÁBITO</label><input name="title" required maxlength="100" value="${esc(h.title)}" placeholder="Ex.: caminhar, estudar, meditar"></div><div class="row"><div class="field"><label>CATEGORIA</label><input name="category" value="${esc(h.category||'Bem-estar')}"></div><div class="field"><label>VEZES POR SEMANA</label><select name="targetPerWeek">${[1,2,3,4,5,6,7].map(n=>`<option value="${n}" ${Number(h.targetPerWeek||5)===n?'selected':''}>${n}x</option>`).join('')}</select></div></div><div class="field"><label>HORÁRIO DE LEMBRETE · OPCIONAL</label><input name="time" type="time" value="${esc(h.time||'')}"></div><button class="btn primary full">${id?'Salvar ritmo':'Criar ritmo'}</button>${id?`<button class="btn danger full" type="button" data-delete-habit="${id}">Excluir ritmo</button>`:''}</form>`)}
  function captureModal(){return sheet('Capture agora',`<form class="form" id="capture-modal-form"><div class="field"><label>TIRE DA CABEÇA</label><textarea name="text" required maxlength="180" placeholder="Ideia, preocupação, coisa para lembrar..."></textarea></div><button class="btn primary full">Mandar para a Caixa</button></form>`)}
  function focusModal(){const active=state.focus?.active,mins=modal.minutes||25;return sheet('Foco EIXO',`<div class="focus-center"><div class="eyebrow">${active?'EM FOCO':'ESCOLHA UM BLOCO'}</div><strong id="focus-time">${active?fmtClock(focusRemaining()):String(mins).padStart(2,'0')+':00'}</strong><p>${active?'Uma coisa por vez. O resto pode esperar.':'Não precisa terminar tudo. Só precisa começar o bloco.'}</p></div>${active?`<div class="row"><button class="btn secondary" data-finish-focus>Concluir agora</button><button class="btn danger" data-cancel-focus>Cancelar</button></div>`:`<div class="focus-presets">${[10,25,50].map(n=>`<button class="${mins===n?'active':''}" data-focus-minutes="${n}">${n} min</button>`).join('')}</div><div class="field"><label>INTENÇÃO · OPCIONAL</label><input id="focus-label" maxlength="80" placeholder="No que você vai focar?"></div><button class="btn primary full" data-start-focus>Iniciar foco</button>`}`)}
  function northModal(){const list=tasksToday().filter(t=>!t.done);return sheet('Norte do Dia',`<p class="muted small" style="line-height:1.5">Escolha no máximo 3 tarefas. Se tudo é prioridade, nada é prioridade.</p><form id="north-form"><div class="list" style="margin:14px 0">${list.length?list.map(t=>`<label class="task north-option"><input type="checkbox" name="north" value="${t.id}" ${t.northDate===todayISO()?'checked':''}><div class="task-body"><div class="task-title">${esc(t.title)}</div><div class="task-meta"><span class="pill">${esc(t.category||'Geral')}</span></div></div></label>`).join(''):`<div class="empty">Crie tarefas para definir seu Norte.</div>`}</div><button class="btn primary full">Guardar meu Norte</button></form>`)}

  function profileModal(){
    const p=state.profile;
    return sheet('Editar perfil',`<form class="form" id="profile-form"><div style="display:flex;justify-content:center">${avatarHtml('profile-avatar')}</div><div class="field"><label>FOTO DE PERFIL</label><input id="avatar-input" type="file" accept="image/*"></div><div class="field"><label>NOME</label><input name="name" required value="${esc(p.name)}"></div><div class="field"><label>E-MAIL</label><input name="email" type="email" value="${esc(p.email)}"></div><div class="row"><div class="field"><label>TELEFONE</label><input name="phone" value="${esc(p.phone||'')}"></div><div class="field"><label>NASCIMENTO</label><input name="birth" type="date" value="${esc(p.birth||'')}"></div></div><div class="field"><label>SOBRE VOCÊ</label><textarea name="bio" placeholder="Uma frase, propósito ou contexto que queira guardar aqui.">${esc(p.bio||'')}</textarea></div><button class="btn primary full" type="submit">Salvar perfil</button></form>`);
  }
  function checkinModal(){
    return sheet('Check-in do dia',`<form class="form" id="checkin-form"><div class="eyebrow">Como você está chegando hoje?</div><div class="mood-grid">${[['Tranquilo','😌'],['Bem','🙂'],['Normal','😐'],['Corrido','😵']].map(([l,i])=>`<button type="button" class="mood-choice ${modal.mood===l?'active':''}" data-mood-choice="${l}"><b>${i}</b><span>${l}</span></button>`).join('')}</div><div class="field"><label>UMA PEQUENA VITÓRIA</label><input name="win" maxlength="140" placeholder="Algo que você fez bem hoje"></div><div class="field"><label>O QUE MERECE ATENÇÃO?</label><textarea name="note" maxlength="300" placeholder="Sem julgamento. Só percepção."></textarea></div><button class="btn primary full">Registrar check-in</button></form>`);
  }
  function render(){
    applyTheme();
    reconcileFocus(false);
    const root=$('#app');
    if(!state.onboarded){ root.innerHTML=onboarding(); bind(); return; }
    if(!state.loggedIn){ root.innerHTML=loginView(); bind(); return; }
    root.innerHTML=appView(); bind(); startFocusTicker();
    const sound=$('#sound-choice');if(sound)sound.value=state.prefs.sound||'pulse';
  }
  function bind(){
    $$('[data-route]').forEach(el=>el.onclick=()=>{route=el.dataset.route;state.lastRoute=route;save();modal=null;render();scrollTo({top:0,behavior:'smooth'})});
    $$('[data-new="task"]').forEach(el=>el.onclick=()=>{modal={type:'task'};render()});
    $$('[data-new="goal"]').forEach(el=>el.onclick=()=>{modal={type:'goal'};render()});
    $$('[data-edit-task]').forEach(el=>el.onclick=()=>{modal={type:'task',id:el.dataset.editTask};render()});
    $$('[data-edit-goal]').forEach(el=>el.onclick=()=>{modal={type:'goal',id:el.dataset.editGoal};render()});
    $$('[data-close-modal]').forEach(el=>el.onclick=()=>{modal=null;render()});
    $('[data-quick-menu]')?.addEventListener('click',()=>{modal={type:'quick'};render()});
    $$('[data-toggle-task]').forEach(el=>el.onclick=e=>{e.stopPropagation();toggleTask(el.dataset.toggleTask)});
    $$('[data-filter]').forEach(el=>el.onclick=()=>{taskFilter=el.dataset.filter;render()});
    $$('[data-plan-tab]').forEach(el=>el.onclick=()=>{planTab=el.dataset.planTab;route='plan';modal=null;render()});
    $('#plan-search')?.addEventListener('input',e=>{planSearch=e.target.value; const pos=e.target.selectionStart; render(); const n=$('#plan-search'); if(n){n.focus();n.setSelectionRange(pos,pos)}});
    $('[data-edit-profile]')?.addEventListener('click',()=>{modal={type:'profile'};render()});
    $$('[data-theme-choice]').forEach(el=>el.onclick=()=>patch(s=>s.prefs.theme=el.dataset.themeChoice));
    $('[data-toggle-mode]')?.addEventListener('click',()=>patch(s=>s.prefs.mode=s.prefs.mode==='dark'?'light':'dark'));
    $$('[data-pref]').forEach(el=>el.onclick=()=>togglePref(el.dataset.pref));
    $('[data-preview-sound]')?.addEventListener('click',()=>playTone(state.prefs.sound||'pulse',true));
    $('#sound-choice')?.addEventListener('change',e=>{state.prefs.sound=e.target.value;save();playTone(e.target.value,true)});
    $('[data-export]')?.addEventListener('click',exportData);
    $('[data-logout]')?.addEventListener('click',()=>patch(s=>s.loggedIn=false));
    $('[data-login]')?.addEventListener('click',()=>patch(s=>s.loggedIn=true));
    $('[data-reset-login]')?.addEventListener('click',()=>{ if(confirm('Isso apaga os dados locais do EIXO neste aparelho. Continuar?')){localStorage.removeItem('eixo_state');localStorage.removeItem('eixo_state_v3');state=structuredClone(defaults);modal={onboardStep:1};render()} });
    $('[data-install]')?.addEventListener('click',installApp);
    $('[data-checkin]')?.addEventListener('click',()=>{modal={type:'checkin',mood:'Normal'};render()});
    $$('[data-mood-choice]').forEach(el=>el.onclick=()=>{modal.mood=el.dataset.moodChoice;render()});
    $('[data-notification-test]')?.addEventListener('click',testNotification);
    $('[data-capture]')?.addEventListener('click',()=>{modal={type:'capture'};render()});
    $('[data-north]')?.addEventListener('click',()=>{modal={type:'north'};render()});
    $$('[data-focus-open]').forEach(el=>el.onclick=()=>{modal={type:'focus',minutes:25};render()});
    $$('[data-focus-minutes]').forEach(el=>el.onclick=()=>{modal.minutes=Number(el.dataset.focusMinutes);render()});
    $('[data-start-focus]')?.addEventListener('click',startFocus);
    $('[data-finish-focus]')?.addEventListener('click',()=>completeFocus(true,true));
    $('[data-cancel-focus]')?.addEventListener('click',()=>{state.focus=structuredClone(defaults.focus);save();modal=null;render();toast('Sessão encerrada.')});
    $$('[data-toggle-habit]').forEach(el=>el.onclick=()=>toggleHabit(el.dataset.toggleHabit));
    $$('[data-edit-habit]').forEach(el=>el.onclick=()=>{modal={type:'habit',id:el.dataset.editHabit};render()});
    $$('[data-new-habit]').forEach(el=>el.onclick=()=>{modal={type:'habit'};render()});
    $$('[data-contribute]').forEach(el=>el.onclick=()=>{modal={type:'contribute',id:el.dataset.contribute};render()});
    $$('[data-inbox-task]').forEach(el=>el.onclick=()=>{const item=state.inbox.find(x=>x.id===el.dataset.inboxTask);if(item){modal={type:'task',prefill:item.text,fromInbox:item.id};render()}});
    $$('[data-delete-inbox]').forEach(el=>el.onclick=()=>{state.inbox=state.inbox.filter(x=>x.id!==el.dataset.deleteInbox);save();render()});

    $('[data-onboard-next]')?.addEventListener('click',()=>{ modal={onboardStep:(modal?.onboardStep||1)+1}; render(); });
    $('[data-onboard-back]')?.addEventListener('click',()=>{ modal={onboardStep:Math.max(1,(modal?.onboardStep||2)-1)}; render(); });
    $$('[data-purpose]').forEach(el=>el.onclick=()=>{const n=Number(el.dataset.purpose); if(state.purposes.includes(n))state.purposes=state.purposes.filter(x=>x!==n);else state.purposes.push(n);save();render()});
    $('[data-onboard-finish]')?.addEventListener('click',finishOnboarding);

    $('#task-form')?.addEventListener('submit',saveTask);
    $('#goal-form')?.addEventListener('submit',saveGoal);
    $('#habit-form')?.addEventListener('submit',saveHabit);
    $('#capture-form')?.addEventListener('submit',saveCapture);
    $('#capture-modal-form')?.addEventListener('submit',saveCapture);
    $('#contribution-form')?.addEventListener('submit',saveContribution);
    $('#north-form')?.addEventListener('submit',saveNorth);
    $('#checkin-form')?.addEventListener('submit',saveCheckin);
    $('#profile-form')?.addEventListener('submit',saveProfile);
    $('[data-delete-task]')?.addEventListener('click',()=>deleteTask($('[data-delete-task]').dataset.deleteTask));
    $('[data-delete-goal]')?.addEventListener('click',()=>deleteGoal($('[data-delete-goal]').dataset.deleteGoal));
    $('[data-delete-habit]')?.addEventListener('click',()=>deleteHabit($('[data-delete-habit]').dataset.deleteHabit));
    $('#goal-progress')?.addEventListener('input',e=>{$('#progress-label').textContent=`${e.target.value}%`});
    $('#goal-type')?.addEventListener('change',e=>{const fin=$('#financial-goal-fields'),gen=$('#general-goal-fields');if(fin&&gen){fin.style.display=e.target.value==='financial'?'block':'none';gen.style.display=e.target.value==='general'?'block':'none'}});
    $('#avatar-input')?.addEventListener('change',handleAvatar);
  }
  function finishOnboarding(){
    const name=$('#on-name')?.value.trim(), email=$('#on-email')?.value.trim();
    if(!name){toast('Digite seu nome para continuar.');$('#on-name')?.focus();return}
    state.profile.name=name; state.profile.email=email; state.onboarded=true; state.loggedIn=true;
    if(!state.tasks.length) state.tasks=seedTasks(); if(!state.goals.length)state.goals=seedGoals();
    if(!state.habits.length)state.habits=[{id:uid(),title:'Cuidar de mim por 10 minutos',category:'Bem-estar',targetPerWeek:5,time:'',completions:[],createdAt:Date.now()}];
    modal=null; save(); render(); setTimeout(()=>toast('Seu EIXO começou.'),120);
  }
  function saveTask(e){
    e.preventDefault(); const f=new FormData(e.currentTarget); const id=e.currentTarget.dataset.id;
    const obj={title:f.get('title').trim(),notes:f.get('notes').trim(),date:f.get('date'),time:f.get('time'),priority:f.get('priority'),category:f.get('category'),repeat:f.get('repeat')||'none',reminder:f.get('reminder')==='on'};
    if(id){const t=state.tasks.find(x=>x.id===id);Object.assign(t,obj)} else state.tasks.push({id:uid(),...obj,done:false,createdAt:Date.now()});
    if(modal?.fromInbox)state.inbox=state.inbox.filter(x=>x.id!==modal.fromInbox);
    save(); modal=null; render(); toast(id?'Tarefa atualizada.':'Tarefa criada.');
    if(obj.reminder) requestNotifications(false);
  }
  function toggleTask(id){
    const t=state.tasks.find(x=>x.id===id); if(!t)return;const was=t.done;t.done=!t.done;t.completedAt=t.done?Date.now():null;
    if(t.done&&!was&&t.repeat&&t.repeat!=='none'&&!t.generatedNext){const d=new Date(`${t.date||todayISO()}T12:00:00`);if(t.repeat==='daily')d.setDate(d.getDate()+1);if(t.repeat==='weekly')d.setDate(d.getDate()+7);if(t.repeat==='monthly')d.setMonth(d.getMonth()+1);state.tasks.push({...t,id:uid(),date:isoDate(d),done:false,completedAt:null,generatedNext:false,northDate:'',notifiedKey:null});t.generatedNext=true}
    save();render();toast(t.done?'Passo concluído. ✓':'Tarefa reaberta.');
  }
  function deleteTask(id){ if(!confirm('Excluir esta tarefa?'))return; state.tasks=state.tasks.filter(x=>x.id!==id);save();modal=null;render();toast('Tarefa excluída.'); }

  function saveGoal(e){
    e.preventDefault();const f=new FormData(e.currentTarget),id=e.currentTarget.dataset.id,old=id?state.goals.find(x=>x.id===id):null,type=f.get('type')||'general';
    const lines=String(f.get('steps')||'').split('\n').map(x=>x.trim()).filter(Boolean);
    const steps=lines.map(line=>{const done=line.startsWith('✓ '),text=done?line.slice(2):line,existing=old?.steps?.find(s=>s.text===text);return{id:existing?.id||uid(),text,done:existing?.done||done}});
    const obj={type,title:f.get('title').trim(),category:f.get('category'),deadline:f.get('deadline'),progress:Number(f.get('progress')||0),steps,currency:f.get('currency')||old?.currency||'BRL',targetAmount:Number(f.get('targetAmount')||0),currentAmount:Number(f.get('currentAmount')||0)};
    if(type==='financial'&&obj.targetAmount<=0){toast('Informe o valor-alvo da meta.');return}
    if(id){const hist=old.financialHistory||[];Object.assign(old,obj);old.financialHistory=hist}else state.goals.push({id:uid(),...obj,financialHistory:[],createdAt:Date.now()});
    save();modal=null;render();toast(id?'Meta atualizada.':'Meta criada.');
  }
  function saveContribution(e){e.preventDefault();const f=new FormData(e.currentTarget),g=state.goals.find(x=>x.id===e.currentTarget.dataset.id),amount=Number(f.get('amount')||0);if(!g||amount<=0)return;g.currentAmount=(Number(g.currentAmount)||0)+amount;g.financialHistory=g.financialHistory||[];g.financialHistory.push({id:uid(),amount,note:String(f.get('note')||'').trim(),at:Date.now()});save();modal=null;render();toast(`Avanço registrado: ${money(amount,g.currency)}`)}
  function saveHabit(e){e.preventDefault();const f=new FormData(e.currentTarget),id=e.currentTarget.dataset.id,old=state.habits.find(x=>x.id===id),obj={title:f.get('title').trim(),category:f.get('category').trim(),targetPerWeek:Number(f.get('targetPerWeek')||5),time:f.get('time')};if(old)Object.assign(old,obj);else state.habits.push({id:uid(),...obj,completions:[],createdAt:Date.now()});save();modal=null;render();toast(id?'Ritmo atualizado.':'Ritmo criado.')}
  function deleteHabit(id){if(!confirm('Excluir este ritmo?'))return;state.habits=state.habits.filter(x=>x.id!==id);save();modal=null;render();toast('Ritmo excluído.')}
  function toggleHabit(id){const h=state.habits.find(x=>x.id===id);if(!h)return;h.completions=h.completions||[];const d=todayISO(),i=h.completions.indexOf(d);if(i>=0)h.completions.splice(i,1);else h.completions.push(d);save();render();toast(i>=0?'Ritmo desmarcado.':'Ritmo cumprido. ✓')}
  function saveCapture(e){e.preventDefault();const f=new FormData(e.currentTarget),text=String(f.get('text')||'').trim();if(!text)return;state.inbox.push({id:uid(),text,createdAt:Date.now()});save();modal=null;render();toast('Guardado na Caixa.')}
  function saveNorth(e){e.preventDefault();const ids=new FormData(e.currentTarget).getAll('north').slice(0,3);state.tasks.forEach(t=>{if(t.northDate===todayISO())t.northDate='' });ids.forEach(id=>{const t=state.tasks.find(x=>x.id===id);if(t)t.northDate=todayISO()});save();modal=null;render();toast('Norte do Dia definido.')}
  function saveCheckin(e){e.preventDefault();const f=new FormData(e.currentTarget);state.checkins.push({id:uid(),date:todayISO(),mood:modal?.mood||'Normal',win:String(f.get('win')||'').trim(),note:String(f.get('note')||'').trim(),createdAt:Date.now()});save();modal=null;render();toast('Check-in registrado.')}
  function startFocus(){const mins=Number(modal?.minutes)||25,label=$('#focus-label')?.value.trim()||'';state.focus={active:true,startedAt:Date.now(),endAt:Date.now()+mins*60000,duration:mins,label};save();modal={type:'focus',minutes:mins};render();toast('Foco iniciado.')}
  function completeFocus(manual=false,notify=true){if(!state.focus?.active)return;const elapsed=Math.max(1,Math.round((Date.now()-Number(state.focus.startedAt))/60000)),duration=manual?elapsed:Number(state.focus.duration)||elapsed;state.focusHistory.push({id:uid(),duration,label:state.focus.label||'',completedAt:Date.now()});state.focus=structuredClone(defaults.focus);save();if(notify){playTone(state.prefs.sound||'pulse');showSystemNotification('EIXO · Bloco concluído',`Você protegeu ${duration} minuto(s) de atenção.`)}modal=null;render();toast('Bloco de foco concluído. ◉')}
  function reconcileFocus(notify=true){if(state.focus?.active&&Number(state.focus.endAt)<=Date.now())completeFocus(false,notify)}
  function startFocusTicker(){clearInterval(focusTicker);if(!state.focus?.active)return;focusTicker=setInterval(()=>{const left=focusRemaining(),a=$('#focus-time'),b=$('#focus-chip-time');if(a)a.textContent=fmtClock(left);if(b)b.textContent=fmtClock(left);if(left<=0){clearInterval(focusTicker);completeFocus(false,true)}},500)}
  async function showSystemNotification(title,body){if(!state.prefs.notifications||Notification.permission!=='granted')return;const reg=await navigator.serviceWorker?.ready;reg?.showNotification(title,{body,icon:'./icons/icon-192.png',badge:'./icons/icon-192.png',tag:`eixo-${Date.now()}`,vibrate:state.prefs.vibrate?[130,80,130]:undefined})}

  function deleteGoal(id){if(!confirm('Excluir esta meta?'))return;state.goals=state.goals.filter(x=>x.id!==id);save();modal=null;render();toast('Meta excluída.');}

  let pendingAvatar=null;
  function handleAvatar(e){const file=e.target.files?.[0];if(!file)return;const r=new FileReader();r.onload=()=>{pendingAvatar=r.result;const img=$('.profile-avatar');if(img)img.innerHTML=`<img src="${r.result}" alt="Nova foto">`};r.readAsDataURL(file)}
  function saveProfile(e){e.preventDefault();const f=new FormData(e.currentTarget);Object.assign(state.profile,{name:f.get('name').trim(),email:f.get('email').trim(),phone:f.get('phone').trim(),birth:f.get('birth'),bio:f.get('bio').trim()});if(pendingAvatar){state.profile.avatar=pendingAvatar;pendingAvatar=null}save();modal=null;render();toast('Perfil atualizado.');}

  async function togglePref(key){
    if(key==='notifications'&&!state.prefs.notifications){const ok=await requestNotifications(true);if(!ok)return}
    patch(s=>s.prefs[key]=!s.prefs[key]);
  }
  async function requestNotifications(showFeedback=true){
    if(!('Notification'in window)){if(showFeedback)toast('Seu navegador não oferece notificações.');return false}
    if(Notification.permission==='granted')return true;
    const p=await Notification.requestPermission();if(showFeedback)toast(p==='granted'?'Notificações ativadas.':'Permissão de notificação não concedida.');return p==='granted';
  }
  async function testNotification(){
    const ok=await requestNotifications();if(!ok)return;playTone(state.prefs.sound||'pulse');
    const reg=await navigator.serviceWorker?.ready;
    if(reg)reg.showNotification('EIXO',{body:'Seu próximo passo importa. As notificações estão funcionando.',icon:'./icons/icon-192.png',badge:'./icons/icon-192.png',tag:'eixo-test',vibrate:state.prefs.vibrate?[120,70,120]:undefined});
    modal=null;render();
  }
  async function checkDueReminders(){
    if(!state.prefs.notifications||Notification.permission!=='granted')return;
    const now=new Date(),k=todayISO(),hhmm=now.toTimeString().slice(0,5),reg=await navigator.serviceWorker?.ready;
    for(const t of state.tasks){
      if(!t.reminder||t.done||t.notifiedKey===`${k}-${t.time}`||t.date!==k||!t.time||t.time>hhmm)continue;
      t.notifiedKey=`${k}-${t.time}`;save();playTone(state.prefs.sound||'pulse');reg?.showNotification('EIXO · Lembrete',{body:t.title,icon:'./icons/icon-192.png',badge:'./icons/icon-192.png',tag:`task-${t.id}`,vibrate:state.prefs.vibrate?[120,70,120]:undefined});
    }
    for(const h of state.habits){
      if(!h.time||(h.completions||[]).includes(k)||h.time>hhmm)continue;h.notified=h.notified||{};if(h.notified[k])continue;h.notified[k]=true;save();playTone(state.prefs.sound||'pulse');reg?.showNotification('EIXO · Seu ritmo pede espaço',{body:h.title,icon:'./icons/icon-192.png',badge:'./icons/icon-192.png',tag:`habit-${h.id}`,vibrate:state.prefs.vibrate?[100,60,100]:undefined});
    }
  }
  function recordMood(mood){state.checkins.push({id:uid(),date:todayISO(),mood,createdAt:Date.now()});save();modal=null;render();toast(`Check-in registrado: ${mood}.`)}
  function exportData(){
    const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`eixo-backup-${todayISO()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),500);toast('Backup exportado.');
  }

  async function installApp(){ if(!deferredInstallPrompt)return; deferredInstallPrompt.prompt(); await deferredInstallPrompt.userChoice; deferredInstallPrompt=null; render(); }

  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;render()});
  window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;toast('EIXO instalado.');render()});
  if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
  setInterval(checkDueReminders,30000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){reconcileFocus(true);checkDueReminders()}});
  window.addEventListener('pageshow',()=>reconcileFocus(true));

  // URL shortcuts from manifest
  const quick=new URLSearchParams(location.search).get('quick');
  if(state.onboarded&&state.loggedIn&&quick){modal={type:quick==='goal'?'goal':'task'};history.replaceState({},'',location.pathname)}

  render();
})();
